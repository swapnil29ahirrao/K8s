package com.example.callingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CallingappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CallingappApplication.class, args);
	}

}
